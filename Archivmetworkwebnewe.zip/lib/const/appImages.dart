// ignore_for_file: constant_identifier_names

class AppImages {
  static String logoText = "assets/icons/logoText.png";
  static String logodark = "assets/icons/logodark.png";
  static String logowhite = "assets/icons/logowhite.png";
////////// icons
  static String shareIos = "assets/icons/share_ios.png";
  static String global = "assets/icons/global.png";
  static String twitter = "assets/icons/twitter.png";
  static String insta = "assets/icons/insta.png";

  static String checkGold = "assets/icons/check_gold.png";
  static String cloth = "assets/icons/cloth.png";
  static String globalBlue = "assets/icons/global_blue.png";
  static String goldcoin = "assets/icons/goldcoin.png";
  static String frame = "assets/icons/frame.png";
  static String hands = "assets/icons/hands.png";
  static String lang = "assets/icons/lang.png";
  static String location = "assets/icons/location.png";
  static String mobile = "assets/icons/mobile.png";
  static String send = "assets/icons/send.png";
  //////// images
  static String profile2 = "assets/images/profile2.png";
}
