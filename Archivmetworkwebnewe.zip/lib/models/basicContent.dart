class BasicContent {
  String number = "";
  double persantageFee = 0.0;
  double serviceFee = 0.0;
  BasicContent();
}
